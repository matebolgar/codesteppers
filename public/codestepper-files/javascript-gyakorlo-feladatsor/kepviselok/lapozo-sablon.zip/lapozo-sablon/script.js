
// State
let pages = [];
let selectedPageIndex = 0;

/*
  1. Oldalletöltéskor kérdezd le az elemeket a fetch function-nel

  2. A pages state változó alá kösd be értékként a következőképp csoportosított elemeket:

        pages = [
          [{...}, {...}, {...}, {...} további 26 elem...], ⭠ első oldal
          [{...}, {...}, {...}, {...} további 26 elem...],
          [{...}, {...}, {...}, {...} további 26 elem...],
          [{...}, {...}, {...}, {...} további 26 elem...],
          ...
        ]
              ⭡
        oldalak tömbje

  3. Készíts renderelő függvényt, ami a selectedPageIndex-edik elemet kiszedi a pages 
     tömbből és az abban lévő képviselőket megjeleníti.

  4. Generáld ki a gombokat

  5. Gombnyomáskor állítsd át a selectedPageIndex értékét és rendereld újra a felületet
*/

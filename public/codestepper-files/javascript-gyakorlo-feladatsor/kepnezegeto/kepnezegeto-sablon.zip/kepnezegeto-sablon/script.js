// State
let elemek = [
  {
    id: 1,
    imageURL: "./images/accountant.jpeg",
    title: "Accountant",
  },
  {
    id: 2,
    imageURL: "./images/photographer.jpeg",
    title: "Photographer",
  },
  {
    id: 3,
    imageURL: "./images/football.jpeg",
    title: "Football player",
  },
  {
    id: 4,
    imageURL: "./images/delivery.jpeg",
    title: "Delivery Guy",
  },
  {
    id: 5,
    imageURL: "./images/ux.jpeg",
    title: "UX Designer",
  },
  {
    id: 6,
    imageURL: "./images/businessman.jpeg",
    title: "Businessman",
  },
  {
    id: 7,
    imageURL: "./images/boss.jpeg",
    title: "Boss",
  },
];

function arrayRotate(arr, count) {
  const ret = arr.slice();
  count -= ret.length * Math.floor(count / ret.length);
  ret.push.apply(ret, ret.splice(0, count));
  return ret;
}
